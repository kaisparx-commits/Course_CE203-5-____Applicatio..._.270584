import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Counter extends JFrame
{
    JTextField answer;
    int count;

    public Counter()
    {
        count = 0;
        answer = new JTextField(5);
        answer.setEditable(false);

        JButton button1 = new JButton("1");
        button1.addActionListener(new ButtonHandler(this, 1));
        JButton button2 = new JButton("10");
        button2.addActionListener(new ButtonHandler(this, 10));
        JButton button3 = new JButton("100");
        button3.addActionListener(new ButtonHandler(this, 100));

        Container c = getContentPane();
        c.setLayout(new FlowLayout());
        c.add(button1);
        c.add(button2);
        c.add(button3);
        c.add(answer);
    }

    public static void main( String[] args )
    {
        Counter c = new Counter();
        c.setSize( 300, 300 );
        c.setVisible( true );
    }
}

class ButtonHandler implements ActionListener
{ private Counter myApp;
    private int amount;

    ButtonHandler(Counter applet, int i)
    { myApp = applet;
        amount = i;
    }

    public void actionPerformed(ActionEvent e)
    { myApp.count += amount;
        myApp.answer.setText(""+myApp.count);
    }
}



