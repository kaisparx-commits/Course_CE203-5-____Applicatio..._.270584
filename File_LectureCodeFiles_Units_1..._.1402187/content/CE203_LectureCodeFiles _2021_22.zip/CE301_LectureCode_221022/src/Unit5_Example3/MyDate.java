package Unit5_Example3;


public class MyDate {

    int day;
    int month;
    int year;

    public MyDate(int d, int m, int y)
    {
        day = d;
        month = m;
        year = y;
    }

    public boolean equals(Object o)
    {
        // check if argument is non-null

        if (o!= null && o instanceof MyDate)  {
            MyDate arg = (MyDate)o;
            return year==arg.year && month==arg.month && day==arg.day;
        }
        else
        {
            return false;
        }
    }

    public static void main(String [] args)
    {
        MyDate d1 = new MyDate(27, 8, 1990);
        MyDate d2 = new MyDate(26, 8, 1990);

        System.out.println(d1.equals(d2));
    }

}
