package Unit3_Example7;

public class SquareSimp4
{
    public static void main( String[] args )
    {
        RadioExample frame = new RadioExample();
    }
}
