package Unit3_Example7;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class RadioExample extends JFrame {
    Color col = Color.red;
    JRadioButton redB, blueB, greenB;

    public RadioExample() {
        add(new JPanel() {
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                System.out.println("colour = "+col.toString());
                g.setColor(col);
                g.fillRect(50,50,100,100);
            }
        }, BorderLayout.CENTER);

        RBHandler rbh = new RBHandler();
        ButtonGroup g = new ButtonGroup();
        redB  = new JRadioButton("red", true);
        blueB   = new JRadioButton("blue", true);
        greenB   = new JRadioButton("green", true);
        redB.addItemListener(rbh);
        blueB.addItemListener(rbh);
        greenB.addItemListener(rbh);

        g.add(redB);
        g.add(blueB);
        g.add(greenB);
        // Same for blue & green.
        JPanel p = new JPanel();
        p.setLayout(new FlowLayout(FlowLayout.CENTER,10,0));
        p.add(redB);
        p.add(blueB);
        p.add(greenB);
        add(p, BorderLayout.SOUTH);
        setSize(300, 300);
        setVisible(true);

        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );	// Close action.
    }

    class RBHandler implements ItemListener {

        public void itemStateChanged(ItemEvent e) {
            if (e.getSource() == redB) {
                System.out.println("test1");
                col = Color.red;
            }
            else if (e.getSource() == blueB) {
                System.out.println("test2");
                col = Color.blue;
            }
            else if (e.getSource() == greenB)
            {
                col = Color.green;
                System.out.println("test3");
            }
            repaint();
        }
    }
}

