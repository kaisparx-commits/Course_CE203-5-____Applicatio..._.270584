package ce203.labs;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SquareApp {

    public static void main(String[] args) {
        FilledFrame frame = new FilledFrame();
        frame.setVisible(true);
    }
}

class FilledFrame extends JFrame {
    int size = 400;

    public FilledFrame() {
        JButton smallButton = new JButton("Small");
        JButton mediumButton = new JButton("Medium");
        JButton largeButton = new JButton("Large");
        JButton messageButton = new JButton("Hello!");

        SquarePanel squarePanel = new SquarePanel(this);
        JPanel buttonPanel = new JPanel();

        buttonPanel.add(smallButton);
        buttonPanel.add(mediumButton);
        buttonPanel.add(largeButton);
        buttonPanel.add(messageButton);
        add(buttonPanel, BorderLayout.NORTH);
        add(squarePanel, BorderLayout.CENTER);

        setSize(this.size + 100, this.size + 100);

        messageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                JOptionPane.showMessageDialog(null, "Hello!");
            }
        });

        class MyButtonHandler implements ActionListener{
            int size;

            public MyButtonHandler(int size) {
                this.size = size;
            }


            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                squarePanel.setSize(this.size, this.size);
            }
        }

        smallButton.addActionListener(new MyButtonHandler(100));
        mediumButton.addActionListener(new MyButtonHandler(200));
        largeButton.addActionListener(new MyButtonHandler(300));
    }
}

class SquarePanel extends JPanel {
    FilledFrame theApp;

    SquarePanel(FilledFrame theApp) {
        this.theApp = theApp;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.GREEN);
        g.fillRect(20, 20, this.theApp.size, this.theApp.size);
    }
}