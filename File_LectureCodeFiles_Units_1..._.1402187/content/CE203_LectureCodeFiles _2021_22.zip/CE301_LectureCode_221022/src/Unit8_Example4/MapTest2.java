package Unit8_Example4;

import java.util.*;
import java.io.*;
public class MapTest2
{
    static HashMap<String,Integer> marks = new HashMap<String,Integer>();

    public static void printNameMarkPair(Map<String, Integer> map) {
        Iterator it = map.entrySet().iterator();

        Map.Entry<String, Integer> tempEntry;
        String tempKey;
        Integer tempValue;

        while(it.hasNext()) {

            tempEntry = (Map.Entry<String, Integer>) it.next();
            tempKey = tempEntry.getKey();
            tempValue = tempEntry.getValue();

            System.out.println(tempKey + ": " + tempValue);
        }
    }

    public static double averageMark(Map<String, Integer> map) throws NumberFormatException{

        if(map.values().size() < 1) return 0;

        Iterator it = map.values().iterator();

        double res = 0;
        int temp;

        while(it.hasNext()) {
            temp = (int)it.next();
            if(temp < 0) throw new NumberFormatException("Student grade must be 0 or positive {" + temp + "}");
            else {
                res += temp;
            }
        }

        return res / map.values().size();
    }

    public static Map.Entry<String, Integer> highestMarkEntry(Map<String, Integer> map) throws NumberFormatException {

        Iterator it = map.entrySet().iterator();

        Map.Entry<String, Integer> res = null;
        Map.Entry<String, Integer> temp;
        int tempValue;

        while(it.hasNext()) {
            temp =  (Map.Entry<String, Integer>) it.next();
            tempValue = temp.getValue();

            if(tempValue < 0) throw new NumberFormatException("Student grade must be 0 or positive {Key:" + temp.getKey() + " Value:" + tempValue + "}");

            if(res == null) {
                res = temp;
            } else {
                if(res.getValue() < tempValue) {
                    res = temp;
                }
            }
        }

        return res;
    }

    public static void main(String[] args)
    { BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
        boolean more = true;
        while (more)
        { System.out.print("Name: ");
            String name = null;
            try
            { name = buf.readLine();
            }
            catch (Exception e)
            {
            }
            System.out.print("Mark: ");
            int mark = 0;
            try
            { mark = Integer.parseInt(buf.readLine().trim());
            }
            catch (Exception e)
            { System.out.println("invalid input - using 0");
            }
            marks.put(name, mark);
            System.out.print("More? ");
            try
            { if (buf.readLine().charAt(0)!='y')
                more = false;
            }
            catch (Exception e)
            {
            }
        }

        System.out.println();

        // show printing method

        printNameMarkPair(marks);

        // show average mark method

        try {
            System.out.println("Average mark: " + averageMark(marks));
        } catch (NumberFormatException e) {
            System.out.println(e.getMessage());
        }

        // show highest entry

        try {
            System.out.println("Highest entry: " + highestMarkEntry(marks));
        } catch (NumberFormatException e) {
            System.out.println(e.getMessage());
        }
    }
}


