package Unit10_Example1;

public class MyRunnableClass implements Runnable {
        public void run(){
            System.out.println("MyClass running");
        }

        public static void main(String[] args)
        {
            Thread t1 = new Thread(new MyRunnableClass ());
            t1.start();
        }
}
