package Unit10_Example1;

public class MyThreadClass extends Thread {
    public void run(){
        System.out.println("MyClass running");
    }

    public static void main(String[] args)
    {
        MyThreadClass t1 = new MyThreadClass ();
        t1.start();
    }
}
