package Unit3_Example1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TextApp1 extends JFrame {
    private JTextField inp, res;

    public TextApp1() {
        JLabel prompt = new JLabel("Type number, press return");
        inp = new JTextField(5);
        res = new JTextField(25);
        res.setEditable(false);
        setLayout(new FlowLayout());
        add(prompt);
        add(inp);
        add(res);
        inp.addActionListener(new ActionListener() {
            public void actionPerformed( ActionEvent e) {
                res.setText(""+Integer.parseInt(inp.getText()) *2 +"");
            }
        });

        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );	// Close action.
    }
    public static void main( String[] args ) {
        TextApp1 a = new TextApp1();
        a.setSize(400,400);
        a.setVisible(true);
    }
}

