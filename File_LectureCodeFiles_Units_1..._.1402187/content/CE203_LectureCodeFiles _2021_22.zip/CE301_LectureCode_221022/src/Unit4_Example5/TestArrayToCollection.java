package Unit4_Example5;

import java.util.*;
public class TestArrayToCollection {

    static <String> void arrayToCol ( String[] a, Collection<String> c ) {
        for( String o : a ) 	{
            c.add(o);	// Correct
        }
    }


    public static void printEvenThenOdd( Collection<Integer> c ) {
        Iterator<Integer> it = c.iterator();
        while ( it.hasNext() ) {
            Integer i = it.next();
                if (i.intValue()%2==0)
                    System.out.println(i);
        }
        it = c.iterator();
        while (it.hasNext()) {
            Integer i = it.next();
                if (i.intValue()%2!=0)
                    System.out.println(i);
        }
    }


    public static void main(String args[])
    {
        String[] strArray = {"ball", "cat", "happy", "mat"};

        Collection<String> strList = new ArrayList<String>();
        Collection<Object> colOb = new ArrayList<Object>();

        TestArrayToCollection.arrayToCol(strArray,strList);
        TestArrayToCollection.arrayToCol(strArray,colOb);

        Iterator strIt = strList.iterator();
        Iterator objIt = colOb.iterator();


        System.out.println("Test .....1");
        while (strIt.hasNext() )
        {
            System.out.println( strIt.next() );
        }

        System.out.println("...........");

        System.out.println("Test .....2");
        while (objIt.hasNext() )
        {
            System.out.println( objIt.next() );
        }


        Collection<Integer> c = new ArrayList<Integer>();

        c.add(1);
        c.add(2);
        c.add(3);
        c.add(4);
        c.add(5);
        c.add(6);
        c.add(7);
        c.add(8);
        c.add(9);


        TestArrayToCollection.printEvenThenOdd(c);

    }
}
