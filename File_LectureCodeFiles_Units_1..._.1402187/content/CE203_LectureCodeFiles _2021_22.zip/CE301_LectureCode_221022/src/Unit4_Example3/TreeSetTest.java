package Unit4_Example3;

import java.util.*;

public class TreeSetTest {

    public static void main (String args[] )
    {
        Collection col = new TreeSet();
        col.add(4);
        int i;

        for (i = 0; i < 6; i++)
        {
            if (col.add(i))
                System.out.println("added " + i);
            else
                System.out.println("could not add "+i);
        }
        for (i = 2; i < 5; i++)
        {
            col.remove(i);
        }
        for (i = 0; i < 7; i++)
        {
            if (col.contains(i))
                System.out.println("found " + i);
            else    System.out.println("could not find "+ i);
        }

    }

}
