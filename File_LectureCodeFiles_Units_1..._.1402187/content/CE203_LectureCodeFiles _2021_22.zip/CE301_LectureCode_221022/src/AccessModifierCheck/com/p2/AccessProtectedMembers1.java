package AccessModifierCheck.com.p2;

import AccessModifierCheck.com.p1.ProtectedMembers;

public class AccessProtectedMembers1 {

    public static void main(String[] args) {

        ProtectedMembers p1 = new ProtectedMembers();

        /*
        // this won't work as p1 is not a subclass of ProtectedMembers and so cannot access its attribute or method.
        System.out.println("Access inherited protected method printi() from a different package = "+p1.printi()); // access inherited protected method printi from a different package
        System.out.println("Access inherited protected attribute i from a different package = "+p1.i); // access inherited protected attrbute i from a different package
        */

    }
}
