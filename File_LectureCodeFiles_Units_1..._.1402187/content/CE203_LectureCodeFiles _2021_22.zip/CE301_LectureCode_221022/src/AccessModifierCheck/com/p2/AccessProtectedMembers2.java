package AccessModifierCheck.com.p2;

import AccessModifierCheck.com.p1.ProtectedMembers;

public class AccessProtectedMembers2 extends ProtectedMembers {

    public static void main(String[] args) {
        AccessProtectedMembers2 a1 = new AccessProtectedMembers2();
        System.out.println("Access inherited protected method printi from a different package = "+a1.printi()); // access inherited protected method printi from a different package
        System.out.println("Access inherited protected attribute i from a different package = "+a1.i); // access inherited protected attrbute i from a different package
    }
}
