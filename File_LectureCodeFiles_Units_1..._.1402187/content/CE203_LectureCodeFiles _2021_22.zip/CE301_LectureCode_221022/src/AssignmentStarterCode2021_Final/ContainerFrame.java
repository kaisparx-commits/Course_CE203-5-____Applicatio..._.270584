package AssignmentStarterCode2021_Final;

import javax.swing.*;
import java.awt.*;

// A skeleton JFrame class has been provided which you would need to modifiy to include the other GUI components
// and functionality specified in the assignment specification
public class ContainerFrame extends JFrame{

    public void createComponents() {

        JPanel panel = new ContainerPanel();
        add(panel, BorderLayout.CENTER);
        setSize(400, 400);
        setVisible(true);
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );	// Close action.
    }

    public static void main(String[] args) {

        ContainerFrame cFrame = new ContainerFrame();
        cFrame.createComponents();
    }

}
