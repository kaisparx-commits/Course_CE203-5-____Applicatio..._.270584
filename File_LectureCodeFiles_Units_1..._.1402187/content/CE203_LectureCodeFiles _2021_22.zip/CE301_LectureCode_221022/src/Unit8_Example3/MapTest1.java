package Unit8_Example3;

import java.util.*;
public class MapTest1 {


    public static void printNameMarkPair(Map<String, Integer> map) {
        Iterator it = map.entrySet().iterator();

        Map.Entry<String, Integer> tempEntry;
        String tempKey;
        Integer tempValue;

        while(it.hasNext()) {

            tempEntry = (Map.Entry<String, Integer>) it.next();
            tempKey = tempEntry.getKey();
            tempValue = tempEntry.getValue();

            System.out.println(tempKey + ": " + tempValue);
        }
    }


    public static void main(String args[])
    {

        Map m = new HashMap();
        m.put( "Bob", 23 );
        m.put( "Tom", -19 );
        m.put( "Sara", 22 );


        Set<Map.Entry<Character,Integer>> s = m.entrySet();
        Iterator<Map.Entry<Character,Integer>> it = s.iterator();

        while (it.hasNext()){
            Map.Entry<Character,Integer> e = it.next();

            if (e.getValue().intValue()<0)
             {
                e.setValue(0);
            }
        }

        MapTest1.printNameMarkPair(m);

    }
}
