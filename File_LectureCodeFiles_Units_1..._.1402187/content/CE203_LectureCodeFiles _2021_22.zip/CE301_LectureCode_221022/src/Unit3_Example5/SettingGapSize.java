package Unit3_Example5;

import java.awt.Button;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Panel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class SettingGapSize {
    public static void main(String[] args) {
        Frame frame = new Frame("SettingGapSize");
        frame.setSize(400, 400);
        frame.add(new GridBagLayoutPanel());
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

class GridBagLayoutPanel extends Panel {
    public GridBagLayoutPanel() {
        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        setLayout(gridbag);
        constraints.weightx = constraints.weighty = 10.0;
        constraints.fill = GridBagConstraints.NONE;
        constraints.ipadx = 30;
        constraints.ipady = 10;
        // Create a 10 pixel gap between columns 0 and 2
        setColumnMinWidth(gridbag, 1, 10);
        // Create a 10 pixel gap between rows 0 and 2
        setRowMinHeight(gridbag, 1, 10);
        addButton("OK", constraints, gridbag);
        constraints.weightx = 5.0;
        constraints.fill = GridBagConstraints.BOTH;
        constraints.ipadx = constraints.ipady = 0;
        constraints.insets = new Insets(10, 30, 10, 20);
        constraints.gridwidth = GridBagConstraints.RELATIVE;
        constraints.gridheight = 2;
        // Create a 10 pixel gap between columns 0 and 2
        setColumnMinWidth(gridbag, 1, 10);
        // Create a 10 pixel gap between rows 0 and 2
        setRowMinHeight(gridbag, 1, 10);
        addButton("GO", constraints, gridbag);
        constraints.insets = new Insets(0, 0, 0, 0);
        constraints.gridx = 0;
        constraints.fill = GridBagConstraints.NONE;
        constraints.ipadx = 30;
        constraints.ipady = 10;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        // Create a 10 pixel gap between columns 0 and 2
        setColumnMinWidth(gridbag, 1, 10);
        // Create a 10 pixel gap between rows 0 and 2
        setRowMinHeight(gridbag, 1, 10);
        addButton("Cancel", constraints, gridbag);
    }

    private void addButton(String label, GridBagConstraints constraints,
                           GridBagLayout layout) {
        Button button = new Button(label);
        layout.setConstraints(button, constraints);
        add(button);
    }

    // Sets the minimum width for column c to be w pixels wide
    public void setColumnMinWidth(GridBagLayout gridbag, int c, int w) {
        int[] ws = gridbag.columnWidths;
        if (ws == null) {
            ws = new int[c + 1];
        } else if (ws.length < c + 1) {
            ws = new int[c + 1];
            System.arraycopy(gridbag.columnWidths, 0, ws, 0,
                    gridbag.columnWidths.length);
        }
        ws[c] = w;
        gridbag.columnWidths = ws;
    }

    // Sets the minimum height for row r to be h pixels high
    public void setRowMinHeight(GridBagLayout gridbag, int r, int h) {
        int[] hs = gridbag.rowHeights;
        if (hs == null) {
            hs = new int[r + 1];
        } else if (hs.length < r + 1) {
            hs = new int[r + 1];
            System.arraycopy(gridbag.rowHeights, 0, hs, 0,
                    gridbag.rowHeights.length);
        }
        hs[r] = h;
        gridbag.rowHeights = hs;
    }
}