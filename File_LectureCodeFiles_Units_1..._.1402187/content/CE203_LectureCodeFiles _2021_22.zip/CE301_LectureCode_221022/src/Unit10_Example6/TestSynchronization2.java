package Unit10_Example6;

//example of java synchronized method
class SyncTable {
    synchronized void printTable(int n){//synchronized method
        for(int i=1;i<=5;i++){
            System.out.println(n*i);
            try{
                Thread.sleep(400);
            }catch(Exception e){System.out.println(e);}
        }

    }
}

class MyThread3 extends Thread{
    SyncTable t;
    MyThread3(SyncTable t){
        this.t=t;
    }
    public void run(){
        t.printTable(5);
    }

}
class MyThread4 extends Thread{
    SyncTable t;
    MyThread4(SyncTable t){
        this.t=t;
    }
    public void run(){
        t.printTable(100);
    }
}

public class TestSynchronization2{
    public static void main(String args[]){
        SyncTable objS = new SyncTable();//only one object
        MyThread3 t1=new MyThread3(objS);
        MyThread4 t2=new MyThread4(objS);
        t1.start();
        t2.start();
    }
}
