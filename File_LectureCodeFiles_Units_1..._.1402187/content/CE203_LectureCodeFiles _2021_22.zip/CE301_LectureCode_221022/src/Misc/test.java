package Misc;

import javax.swing.*;
import javax.swing.JTextArea;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public  class  test extends JFrame {

    JTextField R, G, B;
    JTextField sendMessage;
    JTextArea getMessage;
    // panel
    JPanel p;

    private Object Color;

    public test() {
        R = new JTextField(4);
        G = new JTextField(4);
        B = new JTextField(4);

        List<String> list = new ArrayList<>();

        // create labels
        JLabel l = new JLabel("Red= ");
        JLabel l1 = new JLabel("Green= ");
        JLabel l2 = new JLabel("Blue= ");
        JButton b = new JButton("ok");

        p = new JPanel();
        // add ActionListener

        // add components to panel
        p.add(l);
        p.add(R);
        p.add(l1);
        p.add(G);
        p.add(l2);
        p.add(B);
        p.add(b);

        p.setLocation(500, 600);

        setSize(300, 200);
        add(p);
        setVisible(true);
        show();


        setSize(500, 350);
        setTitle("ID");


        setLayout(null);
        // åˆ›å»ºâ€œç”¨æˆ·åï¼š â€æ ‡ç­¾



        getMessage = new JTextArea(12,20);
        getMessage.setBounds(40, 50, 500, 760);
        getMessage.setEditable(false);//不可编辑
        getMessage.setLineWrap(true);//设置自动换行
        getMessage.setWrapStyleWord(true);//设置以单词为整体换行，(即不会将单词切割成两半)
        JScrollPane scrollPane = new JScrollPane(getMessage);//添加滚动条
        scrollPane.setBounds(5, 0, 250, 160);


        JLabel L1 = new JLabel("ID");
        L1.setBounds(10, 20, 55, 20);
        setResizable(false);
        JPanel ID = new JPanel();
        ID.add(L1);
        JTextField sendMessage = new JTextField(10);
        ID.add(sendMessage);
        sendMessage.setBounds(30, 40, 50, 20);
        //sendMessage = new JTextField(50);
        //sendMessage.setBounds(40, 50, 55, 20);
        ID.setLayout(new FlowLayout());

        sendMessage.setText("");


        add(scrollPane,BorderLayout.CENTER);
        add(sendMessage);
        add(ID,BorderLayout.SOUTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //myEvent();
        setVisible(true);





        sendMessage.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    String msg = sendMessage.getText();
                    getMessage.append("\r\nID ‘ " + msg + " ' has been added to the list");
                    //每次添加信息时刷新文本区域，将滚动条显示在末尾，即显示最新一次输入
                    getMessage.setCaretPosition(getMessage.getText().length());
                    sendMessage.setText(null);
                    //put ArrayCode here



                    list.add(msg);

                    System.out.println(list.size());
                    Iterator<String> it1 = list.iterator();
                    while(it1.hasNext())
                    {
                        String temp = it1.next();
                        System.out.println(temp);

                    }

                    /*
                    for (String tmp : list) {
                        System.out.println(tmp);
                    }
                    */

                    /*
                    list.add(String.valueOf(sendMessage));
                    boolean getMessage = false;
                    for(String value : list) {
                        if (value.equals(sendMessage)) {
                            getMessage = true;
                            break;
                        }
                    }
                    if(!getMessage){
                        list.add(String.valueOf(sendMessage));
                    }
                    System.out.println(list);

                     */
                }
            }
        });

        // åˆ›å»ºâ€œç¡®å®šâ€æŒ‰é’®
        JButton btn = new JButton("confirm");
        // â€œç¡®å®šâ€æŒ‰é’®èŽ·å–ç”¨æˆ·åå’Œå¯†ç 
        btn.addActionListener((ActionEvent e) -> {
            String msg = sendMessage.getText();
            getMessage.append("\r\nID ‘ " + msg + " ' has been added to the list");
            //每次添加信息时刷新文本区域，将滚动条显示在末尾，即显示最新一次输入
            getMessage.setCaretPosition(getMessage.getText().length());
            sendMessage.setText(null);
        });

        btn.setBounds(40, 110, 80, 30);


        // åˆ›å»ºâ€œæ¸…é™¤â€æŒ‰é’®
        JButton btn2 = new JButton("Reset");
        // â€œæ¸…é™¤â€æŒ‰é’®å¯æƒ…å†µç”¨æˆ·åå’Œå¯†ç ä¸­çš„æ–‡æœ¬
        btn2.addActionListener((ActionEvent e) -> {
            sendMessage.setText("");
        });
        btn2.setBounds(130, 110, 80, 30);


        JButton btn3 = new JButton("Clear");
        btn3.addActionListener((ActionEvent e) -> {
            getMessage.setText("");
        });
        btn3.setBounds(130, 110, 80, 30);


        //GridBagConstraints gbc = new GridBagConstraints();
        //setLayout(new GridLayout())
        //add(L1);
        //gbc.gridx = 0;
        //gbc.gridy = 0;
        add(btn, "East", 0);
        add(btn2, "West", 1);
        add(btn3, "South", 2);
        setLayout(new FlowLayout(FlowLayout.CENTER));


        b.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent actionEvent) {
                                    // private ActionEvent evt;
                                    //String s = evt.getActionCommand();
                                    //if (s.equals("ok")) {
                                    int r, g, b, a;

                                    // get rgba velue
                                    r = Integer.parseInt(R.getText());
                                    g = Integer.parseInt(G.getText());
                                    b = Integer.parseInt(B.getText());


                                    // create a new Color
                                    Color c = new Color(r, g, b);

                                    // set the color as background of panel
                                    getMessage.setForeground(c);
                                }

                            }
        );


        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);



    }

    public static void main(String[] args) {
        test password = new test();
    }
}
