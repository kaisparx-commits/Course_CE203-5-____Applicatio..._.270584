package Unit4_Example2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TextApp3 extends JFrame {
    private JTextField res;
    private JButton inp;

    public TextApp3() {
        JLabel prompt = new JLabel("Type number, press return");
        inp = new JButton("Enter Number");
        res = new JTextField(25);
        res.setEditable(false);
        setLayout(new FlowLayout());
        add(prompt);
        add(inp);
        add(res);
        inp.addActionListener(new ActionListener() {

            public void actionPerformed( ActionEvent e) {

                try
                {
                    String number = JOptionPane.showInputDialog("Please type in a number ");
                    res.setText(""+Double.parseDouble(number) *2 +"");
                }
                catch(NumberFormatException ex)
                {
                    JOptionPane.showMessageDialog(null, "The number you entered is not a valid Integer", "Invalid Input", JOptionPane.WARNING_MESSAGE);

                }

            }
        });

        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );	// Close action.
    }
    public static void main( String[] args ) {
        TextApp3 a = new TextApp3();
        a.setSize(400,400);
        a.setVisible(true);
    }
}

