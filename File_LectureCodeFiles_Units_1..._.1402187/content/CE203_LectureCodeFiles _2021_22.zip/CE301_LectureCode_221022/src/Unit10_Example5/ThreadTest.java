package Unit10_Example5;

public class ThreadTest {
    public static void main( String[] args ) {
        ThreadB b = new ThreadB();
        b.start();
        synchronized(b) {
            try {
                System.out.println("Waiting on b…");
                b.wait();
            } catch( InterruptedException e ) {
                e.printStackTrace();
            }
            System.out.println("Total is: " + b.total);
        }
    }
}