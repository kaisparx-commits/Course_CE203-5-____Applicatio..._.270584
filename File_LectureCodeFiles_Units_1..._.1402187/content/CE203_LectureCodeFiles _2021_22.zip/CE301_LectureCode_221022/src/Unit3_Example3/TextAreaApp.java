package Unit3_Example3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TextAreaApp extends JFrame{

    private JTextArea myTextArea;
    private JTextField output;

    public TextAreaApp() {
        super( "Text example" );

        JPanel textAreaPanel = new JPanel();

        JPanel textFieldPanel = new JPanel();

        myTextArea = new JTextArea("This is the first line\n" + "and this is the second line", 12, 20);
        myTextArea.setLineWrap(true);
        output = new JTextField(20);

        textAreaPanel.add(new JScrollPane(myTextArea, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER));

        textFieldPanel.add(output);
        add(textAreaPanel, BorderLayout.NORTH);
        add(textFieldPanel, BorderLayout.SOUTH);


        myTextArea.addMouseListener(new MouseAdapter()  {
            @Override
            public void mouseClicked(MouseEvent e) {
                output.setText("");
            }

            @Override
            public void mousePressed(MouseEvent e) {
                output.setText("");
            }

            @Override
            public void mouseReleased(MouseEvent e) {

                if(myTextArea.getSelectedText() == null)
                    output.setText("");
                else
                    output.setText(""+myTextArea.getSelectedText()+"");
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                //output.setText("");
            }

            @Override
            public void mouseExited(MouseEvent e) {
                //output.setText("");
            }
        });

        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );	// Close action.

    }

    public static void main( String[] args ) {
        TextAreaApp app = new TextAreaApp();

        app.setSize(400,400);
        app.setVisible(true);
    }

}
