package Unit3_Example6;

import javax.swing.*;
import java.awt.*;

public class FilledFrame3 extends JFrame {
    Color col = Color.red;
    JButton butR;
    JButton butG;
    JButton butB;

    public void createComponents() {

        ButtonHandler3 bh = new ButtonHandler3(this);
        butR = new JButton("Red");
        butG = new JButton("Green");
        butB = new JButton("Blue");
        butR.addActionListener(bh);
        butG.addActionListener(bh);
        butB.addActionListener(bh);
        SquarePanel3 panel = new SquarePanel3(this);
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(butR);
        buttonPanel.add(butG);
        buttonPanel.add(butB);
        add(buttonPanel, BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );	// Close action.
    }
}

