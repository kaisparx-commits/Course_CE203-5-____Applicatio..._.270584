package Unit3_Example6;

public class SquareSimp3
{
    public static void main( String[] args )
    {
        FilledFrame3 frame = new FilledFrame3();
        frame.createComponents();
        frame.setSize( 500, 500 );
        frame.setVisible( true );
    }
}
