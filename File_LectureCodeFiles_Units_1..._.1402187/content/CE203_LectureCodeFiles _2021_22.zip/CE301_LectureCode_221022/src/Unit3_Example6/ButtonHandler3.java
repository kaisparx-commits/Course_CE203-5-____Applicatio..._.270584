package Unit3_Example6;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class ButtonHandler3 implements ActionListener {
    FilledFrame3 theApp;

    ButtonHandler3(FilledFrame3 app ) {
        theApp = app;
    }

    public void actionPerformed(ActionEvent e) {
        if( e.getSource()==theApp.butR )
                theApp.col = Color.red;
            else if(e.getSource()==theApp.butG)
                theApp.col = Color.green;
            else
                theApp.col = Color.blue;

            theApp.repaint();
    }
}

