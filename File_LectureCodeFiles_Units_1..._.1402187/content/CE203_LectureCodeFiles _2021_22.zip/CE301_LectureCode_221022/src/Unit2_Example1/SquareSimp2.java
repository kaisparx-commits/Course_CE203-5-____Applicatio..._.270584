package Unit2_Example1;

public class SquareSimp2
{
    public static void main( String[] args )
    {
        FilledFrame2 frame = new FilledFrame2();
        frame.createComponents();
        frame.setSize( 500, 500 );
        frame.setVisible( true );
    }
}
