package Unit2_Example1;

import javax.swing.*;
import java.awt.*;

public class FilledFrame2 extends JFrame {
    Color col = Color.red;

    public void createComponents() {
        JButton but = new JButton("Press me");
        but.addActionListener(new ButtonHandler2(this));
        SquarePanel2 panel = new SquarePanel2(this);
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(but);
        add(buttonPanel, BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );	// Close action.
    }
}

