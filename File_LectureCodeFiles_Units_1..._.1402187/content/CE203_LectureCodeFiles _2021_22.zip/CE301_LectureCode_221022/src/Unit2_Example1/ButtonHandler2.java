package Unit2_Example1;

import java.awt.*;
import java.awt.event.*;

class ButtonHandler2 implements ActionListener {
    FilledFrame2 theApp;

    ButtonHandler2(FilledFrame2 app ) {
        theApp = app;
    }

    public void actionPerformed(ActionEvent e) {
        if (theApp.col==Color.blue)
            theApp.col = Color.red;
        else
            theApp.col = Color.blue;
        theApp.repaint();
    }
}

