package Unit2_Example1;

import javax.swing.*;
import java.awt.*;

class SquarePanel2 extends JPanel {
    FilledFrame2 theApp;
    SquarePanel2(FilledFrame2 app ) {
        theApp = app;
    }

    public void paintComponent( Graphics g ) {
        super.paintComponent( g );
        g.setColor( theApp.col );
        g.fillRect( 20, 30, 40, 40 );
    }
}

