package Unit3_Example2;

import javax.swing.*;
import java.awt.*;

public class Greeting3 {
    public static void main( String[] args ) {
        JFrame frame = new JFrame();
        frame.setSize( 500, 500 );

        frame.add( new JLabel("Hello"), BorderLayout.NORTH );
        frame.add(new JPanel() {
            public void paintComponent(Graphics g)       {
                super.paintComponent(g);
                g.setColor(Color.blue);
                g.drawRect(50, 100, 40, 30);
                g.fillRect(120, 100, 30, 40);
            }
        }, BorderLayout.CENTER);
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );	// Close action.

        frame.setVisible( true );
    }
}