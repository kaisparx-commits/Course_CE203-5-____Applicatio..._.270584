package Unit10_Example2;


public class testThreads {
    public static void main( String[] args ) {

        runDemo r1 = new runDemo( "Thread A" );
        runDemo r2 = new runDemo( "Thread B" );
        r1.start();
        r2.start();


    }
}