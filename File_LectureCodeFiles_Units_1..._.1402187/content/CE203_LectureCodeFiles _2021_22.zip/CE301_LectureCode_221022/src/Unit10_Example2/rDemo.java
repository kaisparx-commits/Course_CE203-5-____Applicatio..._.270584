package Unit10_Example2;

class runDemo implements Runnable {
    private Thread t;
    private String tName;

    runDemo( String name ) {
        tName = name;
        System.out.println( "Creating " + tName );
    }

    public void run() {
        System.out.println( "Running " + tName );

        for( int i = 5; i > 0; i-- ) {
            System.out.println( "Thread: " + tName + "," + i );
        }
        System.out.println( "Thread " + tName + " exiting" );
    }

    public void start() {
        System.out.println( "Starting " + tName );
        if( t == null ) {
            t = new Thread( this, tName );
            t.start();
        }
    }
}