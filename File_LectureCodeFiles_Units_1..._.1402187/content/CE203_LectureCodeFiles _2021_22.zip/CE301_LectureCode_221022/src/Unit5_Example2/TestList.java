package Unit5_Example2;

import java.util.*;

public class TestList {

    public static void lowerCase( List<String> l ){
        ListIterator<String> it = l.listIterator();
        while (it.hasNext())
        {
            String s = it.next().toLowerCase();
            it.set(s);
        }
    }



    public static void main(String args[])
    {
        List<String> l = new ArrayList<String>();

        l.add("A");
        l.add("B");
        l.add("C");
        l.add("D");
        l.add("D");
        l.add("E");

        l.remove(new String("A"));

        for (int i = 0; i < l.size(); i++)
        {
            System.out.println(l.get(i));
        }

        System.out.println();

        List sub = l.subList(1,3);

        for (int i = 0; i < sub.size(); i++)
        {
            System.out.println(sub.get(i));
        }

        sub.set(0,new String("V"));

        System.out.println();

        for (int i = 0; i < sub.size(); i++)
        {
            System.out.println(sub.get(i));
        }

        TestList.lowerCase(sub);

        System.out.println();

        for (int i = 0; i < sub.size(); i++)
        {
            System.out.println(sub.get(i));
        }

    }
}
