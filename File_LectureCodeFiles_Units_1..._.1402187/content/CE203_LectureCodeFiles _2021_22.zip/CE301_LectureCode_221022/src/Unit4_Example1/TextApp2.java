package Unit4_Example1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TextApp2 extends JFrame {
    private JTextField inp, res;

    public TextApp2() {
        JLabel prompt = new JLabel("Type number, press return");
        inp = new JTextField(5);
        res = new JTextField(25);
        res.setEditable(false);
        setLayout(new FlowLayout());
        add(prompt);
        add(inp);
        add(res);
        inp.addActionListener(new ActionListener() {

            public void actionPerformed( ActionEvent e) {

                try
                {
                    res.setForeground(new Color(200, 100, 67));
                    res.setText(""+Integer.parseInt(inp.getText()) *2 +"");
                }
                catch(NumberFormatException ex)
                {
                    JOptionPane.showMessageDialog(null, "The number you entered is not a valid Integer", "Invalid Input", JOptionPane.WARNING_MESSAGE);

                }

            }
        });

        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );	// Close action.
    }
    public static void main( String[] args ) {
        TextApp2 a = new TextApp2();
        a.setSize(400,400);
        a.setVisible(true);
    }
}

