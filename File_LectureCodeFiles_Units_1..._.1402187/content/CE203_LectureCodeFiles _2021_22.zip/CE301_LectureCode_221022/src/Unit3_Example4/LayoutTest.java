package Unit3_Example4;

import javax.swing.*;
import java.awt.*;

public class LayoutTest extends JFrame {
        public LayoutTest() {
            super("Layout test");

            /*
            // Flow Layout
            FlowLayout layout = new FlowLayout(FlowLayout.CENTER, 40, 100);
            setLayout(layout);
            add(new JButton("Ok"));
            add(new JButton("Cancel"));
            setSize(400, 200);
            setVisible(true);
             */

            JPanel panel = new JPanel();
            panel.setLayout( new BoxLayout( panel, BoxLayout.Y_AXIS ));
            for( int i = 1; i < 4; i++ )
            {
                panel.add( new JButton("Button "+i ) );
            }
            add(panel);
            setSize(400, 200);
            setVisible(true);



            /*
            // Grid layout
            setLayout(new GridLayout(3,4,10,12));
            for (int i = 1; i<=12; i++)
                add(new JButton(""+i));

            setSize(400, 200);
            setVisible(true);
            */

            // gridbag layout
            /*
            GridBagLayout g = new GridBagLayout();
            setLayout(g);
            GridBagConstraints gbc = new GridBagConstraints();

            JLabel l = new JLabel("Hello");
            gbc.gridx = 0;
            gbc.gridy = 0;
            g.setConstraints(l, gbc);
            add(l);

            JButton b = new JButton("b1");
            gbc.gridx = 1;      			     // gridy still 0
            gbc.insets = new Insets(0,10,0,0);
            g.setConstraints(b, gbc);
            add(b);

            JTextField t = new JTextField(20);
            gbc.gridy = 1;      			     // gridx still 1
            gbc.gridwidth = 2;
            gbc.insets = new Insets(10,10,0,0);
            g.setConstraints(t, gbc);
            add(t);

            setSize(400, 200);
            setVisible(true);
            */

            setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );	// Close action.
        }

    public static void main( String[] args ) {
        LayoutTest app = new LayoutTest();
    }
}
