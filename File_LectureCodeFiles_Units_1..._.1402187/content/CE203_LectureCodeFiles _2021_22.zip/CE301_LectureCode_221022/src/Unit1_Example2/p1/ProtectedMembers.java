package Unit1_Example2.p1;

public class ProtectedMembers {

    protected int i = 900;
    protected String printi()
    {
        return (" i = "+i);
    }
}