package Unit1_Example3;

import Unit2_Example1.FilledFrame2;

import javax.swing.*;
import java.awt.*;


public class ShapePanel extends JPanel{

        Shape shape;
        ShapePanel(Shape si) {
            shape = si;
        }

        public void paintComponent( Graphics g ) {
            super.paintComponent( g );
            shape.draw(g);
        }
}
