package Unit1_Example3;

import java.awt.*;

public abstract class Shape {

    protected Color  col;
    protected int 	xpos, ypos;

    public Shape(Color c, int x, int y) {
        col = c; xpos = x; ypos = y;
    }

    public void setColor(Color c) {
        col = c;
    }


    // abstract method
    public abstract void draw(Graphics g);

}
