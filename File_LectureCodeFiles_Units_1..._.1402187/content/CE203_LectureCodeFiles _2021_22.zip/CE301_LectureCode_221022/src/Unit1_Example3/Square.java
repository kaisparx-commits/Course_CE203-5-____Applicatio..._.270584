

package Unit1_Example3;

import java.awt.*;

public class Square extends Shape{

    private Color col;
    private int 	xpos, ypos, slen; // centre cords & side length

    public Square(Color c, int x, int y, int s) {
        super(c, x, y);
        col = c; xpos = x; ypos = y; slen = s;
    }

    public void setColor(Color c) {
        col = c;
    }


    public void draw(Graphics g) {
        g.setColor(col);
        g.drawRect(xpos-slen/2, ypos-slen/2, slen, slen);  }


}
