
package Unit1_Example3;


import javax.swing.*;
import java.awt.*;

public class DrawFrame extends JFrame{

    Color col = Color.red;

    public void createComponents(Shape s) {
        ShapePanel panel = new ShapePanel(s);
        add(panel, BorderLayout.CENTER);
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );	// Close action.
    }

}
