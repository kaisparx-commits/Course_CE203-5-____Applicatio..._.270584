package Unit1_Example3;

import java.awt.*;


public class TestDrawShape
{
    public static void main( String[] args )
    {

        Shape square = new Square(Color.red, 100, 200, 100);

        DrawFrame frame = new DrawFrame();
        frame.createComponents(square);
        frame.setSize( 500, 500 );
        frame.setVisible( true );
    }
}
