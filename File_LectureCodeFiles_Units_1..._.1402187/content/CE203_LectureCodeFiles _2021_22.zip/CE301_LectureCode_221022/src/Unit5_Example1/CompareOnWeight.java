package Unit5_Example1;

import java.util.Comparator;

// Comparator class for comparing height weight objects based on weight
public class CompareOnWeight implements Comparator<HumanHeightWeight> {


    @Override
    // compares height weight objects based on weight in kgs
    public int compare(HumanHeightWeight ht1, HumanHeightWeight ht2) {

        if(ht1.getWeight() == ht2.getWeight())  return 0;
        else if(ht1.getWeight() < ht2.getWeight()) return -1;
        else return 1;
    }
}
