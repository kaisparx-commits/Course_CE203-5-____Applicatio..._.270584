package Unit5_Example1;

// Wrapper for a Height Weight object
public class HumanHeightWeight implements Comparable<HumanHeightWeight>{

    private double heightInMeters = 0;
    private double weightInKgs = 0;

    // constructor for creating a valid height / weight object
    public HumanHeightWeight(String height, String weight)
    {
        try {
            heightInMeters = Double.parseDouble(height);
            weightInKgs = Double.parseDouble(weight);
        }
        catch(NullPointerException e1)
        {
            System.out.println("Input string object = null");
        }
        catch(NumberFormatException e2)
        {
            System.out.println("input object not a legal height");
        }
    }

    // get method to get height in meters attribute
    public double getHeight()
    {
        return heightInMeters;
    }

    // get method to get weight in kgs attribute
    public double getWeight()
    {
        return weightInKgs;
    }

    @Override
    // compares height weight objects based on height
    public int compareTo(HumanHeightWeight comparedHeight) {

        if(this.heightInMeters == comparedHeight.heightInMeters)  return 0;
        else if(this.heightInMeters < comparedHeight.heightInMeters) return -1;
		else return 1;

		// could be also replaced with the static method Double.compare();

    }

    public String toString()
    {
        return ("Height is "+heightInMeters +" meters and weight is "+weightInKgs+" kgs");
    }
}
