package Unit8_Example2;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

public class FileReadWrite2 {

    private static int value = 0;

    public static void main(String args[])
    {



        //String a[] = new String[] { "Line 1", "Line 2", "Line 3", "Line 4" };
        //List<String> l = Arrays.asList(a);


        try {

            FileWriter f = new FileWriter("testfile2.txt", true);
            BufferedWriter bw = new BufferedWriter(f);
            PrintWriter ou = new PrintWriter(bw);
            ou.println("Line 5 "+value+" mmm");
            ou.close();

            BufferedReader br = new BufferedReader( new FileReader("testfile2.txt") );
            String linesRead = null;
            while((linesRead = br.readLine()) != null)
            {
                System.out.println(linesRead);
            }
            br.close();
        }
        catch(IOException e){

            System.out.println(e.getMessage());

        }

    }

}
