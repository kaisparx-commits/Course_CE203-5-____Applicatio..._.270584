package Unit8_Example1;

import java.io.IOException;
import java.nio.charset.*;
import java.util.*;
import java.nio.file.*;
import java.io.*;

public class FileReadWrite {

    public static void main(String args[])
    {

        String a[] = new String[] { "Line 1", "Line 2", "Line 3", "Line 4" };
        List<String> l = Arrays.asList(a);


        try {

            Path file = Paths.get("texFile.txt");
            Files.write(file, l, Charset.defaultCharset());

            File fil = file.toFile();
            //File fil = new File("texFile.txt");
            FileWriter f = new FileWriter(fil, true);
            BufferedWriter bw = new BufferedWriter(f);
            PrintWriter ou = new PrintWriter(bw);
            ou.println("Line 5");
            ou.close();


            BufferedReader br = new BufferedReader( new FileReader("texFile.txt") );
            String linesRead = null;
            while((linesRead = br.readLine()) != null)
            {
                System.out.println(linesRead);
            }
            br.close();
        }
        catch(IOException e){

            System.out.println(e.getMessage());

        }

    }

}
