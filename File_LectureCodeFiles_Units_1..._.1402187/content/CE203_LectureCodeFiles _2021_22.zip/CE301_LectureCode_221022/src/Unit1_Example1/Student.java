package Unit1_Example1;

public class Student {

    private int regNo;
    public Student(String s, int age, int r) {

        regNo = r;
    }
    public int regNumber()  {
        return regNo;
    }

    public String toString()  {
        return super.toString() + " Regno: " + regNo;
    }

}
