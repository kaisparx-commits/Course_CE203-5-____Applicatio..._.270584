package Unit1_Example1;


import java.sql.Date;

public class PersonTest {

    public static void main(String[] args) {
        Person p1 = new Person("James Smith", 28);
        Person p2 = new Person("Will Smith", 53);

        System.out.println(p1.toString());

        //Person harry = new Student("Harry Potter", 14 , 9907077);


    }
}
