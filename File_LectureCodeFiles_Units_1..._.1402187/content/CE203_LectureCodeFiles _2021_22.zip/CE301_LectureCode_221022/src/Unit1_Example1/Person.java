package Unit1_Example1;

public class Person
{
    private String name;
    private int age;

    public Person(String nameIn, int ageIn)
    {
        name = nameIn;
        age = ageIn;
    }

    public void setName(String aName)
    {
        name = aName;
    }

    public String getName( )
    {
        return name;
    }

    public int getAge()
    {
        return age;
    }

    public boolean isOlder(Person p)
    {
        return getAge() > p.getAge();
    }


    public String toString() {
        String state = "Name: " + getName() + "\n"
                + "Age : " + getAge();
        return state;
    }
}




