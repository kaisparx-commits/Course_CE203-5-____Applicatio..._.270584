package Unit4_Example4;

public class Person implements Comparable<Person>{

    private String name = null;
    private int age = 0;
    private int uniqueID = 0;

    Person(String nameIn, int ageIn, int id)
    {
        age = ageIn;
        name = nameIn;
        uniqueID = id;
    }

    public String getName()
    {
        return name;
    }

    public int getAge()
    {
        return age;
    }

    public int getUniqueID() {
        return uniqueID;
    }

    public int compareTo(Person p)
    {
        if (getUniqueID() < p.getUniqueID())
            return -1 ;
        if (getUniqueID() == p.getUniqueID())
            return 0;
        return 1;

    }


    public boolean equals(Object o)
    {
        if (getUniqueID() == ((Person)o).getUniqueID())
            return true;
        else
            return false;
    }



    public String toString()
    {
        return ("Name: "+this.name+" Age: "+this.age+" ID: "+this.uniqueID+"\n");
    }
}
