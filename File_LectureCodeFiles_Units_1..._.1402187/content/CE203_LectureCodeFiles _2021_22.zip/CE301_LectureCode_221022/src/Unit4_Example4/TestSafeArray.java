package Unit4_Example4;

public class TestSafeArray {

    public static void main(String args[])
    {
        SafeArray safe = new SafeArray();

        /*
        safe.add(new Person("Tom", 45, 7678));
        safe.add(new Person("John", 26, 7548));
        safe.add(new Person("Yousuf",32, 7500));
        safe.add(new Person("Camron", 18, 7678));
        safe.add(new Person("Lucy", 27, 7780));
        safe.add(new Person("Jason", 52, 7250));
        safe.add(new Person("Camron", 18, 7678));
        safe.add(new Person("Camron", 18, 7678));
        safe.add(new Person("Rebecca", 23, 7100));

         */

        safe.add(new Person("Tom", 45, 7548));
        safe.add(new Person("John", 26, 7548));
        safe.add(new Person("Camron", 18, 7548));


        System.out.println("get first element of array");
        System.out.println(safe.get(7548).toString());

        System.out.println("Unsorted array");
        System.out.println(safe.toString());

        System.out.println("Removed ID array 7548");
        safe.removeAllOccurances(7548);
        System.out.println(safe.toString());

        System.out.println("Sorted array");
        safe.sortPersons();
        System.out.println(safe.toString());
    }

}
