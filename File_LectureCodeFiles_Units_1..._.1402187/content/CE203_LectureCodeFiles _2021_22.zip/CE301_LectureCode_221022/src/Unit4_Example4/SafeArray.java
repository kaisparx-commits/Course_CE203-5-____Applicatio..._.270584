package Unit4_Example4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Iterator;

public class SafeArray {

    private List<Person> myList;

    public SafeArray() {

        myList = new ArrayList<Person>();
    }

    public boolean add(Person p) {

        return myList.add(p);
    }


    // removes single cccurance
    public boolean removeSingle(int ID) {

        Iterator<Person> it = myList.iterator();

        while(it.hasNext())
        {
            if(((it.next().getUniqueID() == ID)))
            {
                it.remove();
            }
        }
        return false;
    }


    // removes multiple occurance of item in list
    public boolean removeAllOccurances(int ID) {

        for(int i = 0; i < myList.size(); i++)
        {
            Person p1 = get(ID);

            if(p1 != null)
            {
                List<Person> temp = new ArrayList<Person>();
                temp.add(p1);
                return myList.removeAll(temp);
            }
        }
        return false;
    }


    public Person get(int ID) {

        for(int i = 0; i < myList.size(); i++)
        {
            if(myList.get(i).getUniqueID() == ID)
            {
                return myList.get(i);
            }
        }
        return null;
    }

    public void sortPersons() {

        Collections.sort(myList);
    }



    public String toString(){

        StringBuffer out = new StringBuffer();
        for(int i = 0; i < myList.size(); i++)
        {
            out.append(myList.get(i).toString());
        }

        return out.toString();
    }

}

