package Unit4_Example6;

import java.util.*;
public class DivideByZeroException extends ArithmeticException {

    public DivideByZeroException(String error)
    {
        super(error);
    }
}
