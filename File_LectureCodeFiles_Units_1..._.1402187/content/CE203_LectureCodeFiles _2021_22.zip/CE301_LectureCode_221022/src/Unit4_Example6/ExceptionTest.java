package Unit4_Example6;

public class ExceptionTest {


    public static int stringToNum(String numValue) {

        //try{
            return Integer.parseInt(numValue);
        //}
        //catch(NumberFormatException e)
        //{
            //System.out.println("invalid int value");
           //return 0;
        //}


    }

    public static double quotient(double num, double den) throws DivideByZeroException {
        if (den==0) {
            throw new DivideByZeroException("cannot divide by zero ");
        }
        return (num / den);

    }


    public static void main(String[] args) /*throws DivideByZeroException*/ {


        //int value = ExceptionTest.stringToNum("g");
        //System.out.println("Value = "+value);


        try {
            double value = ExceptionTest.quotient(7, 0);
            System.out.println("Value = " + value);
        } catch (DivideByZeroException e) {
            System.out.println("operation did not work due to den = 0");
        } finally {

            // always executed(even without catch block

        }
    }
}
