import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


// Controller Class
public class Controller {
    private Model model;   // reference to Model object

    private final JSlider percentageSlider;

    // Controller constructor
    public Controller(String title) {

        // Initialises Controller GUI
        // Controller uses Swing framework to display UI to user
        JFrame controllerFrame = new JFrame(title);
        percentageSlider= new JSlider(0, 100, 0);
        percentageSlider.setPaintTrack(true);
        percentageSlider.setPaintTicks(true);
        percentageSlider.setPaintLabels(true);
        percentageSlider.setMajorTickSpacing(20);
        percentageSlider.setMinorTickSpacing(5);
        JPanel sliderPanel = new JPanel();
        sliderPanel.add(percentageSlider);
        controllerFrame.add(sliderPanel);
        controllerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        controllerFrame.setSize(500, 200);
        controllerFrame.setLocationRelativeTo(null);
        controllerFrame.setVisible(true);
    }

    // Setting of event handling of slider component
    public void initController() {

        //  Anonymous Inner class for adding change listener to slider
        percentageSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                updateModel();
            }
        });
    }

    // Controller references a Model
    public void linkToModel(Model m){
        this.model = m;
    }

    // Updates value(s) in Model
    public void updateModel()
    {
        int value = percentageSlider.getValue();
        model.setModelValue(value);
        System.out.println("Percentage value in Model set to " + value + " ---> Controller Manipulates Model");
    }
}
