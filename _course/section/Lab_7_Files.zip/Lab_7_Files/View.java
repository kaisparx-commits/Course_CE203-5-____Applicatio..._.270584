
// View Class
public class View {

    // View constructor (to be completed)
    public View(String title) {

        // Initialises View GUI
        // View uses Swing framework to display UI to user (to be completed by creating a new frame and text field)
    }

    // Updates view component with parameter value (to be completed)
    public void update(int updatedValue)
    {
    }
}
