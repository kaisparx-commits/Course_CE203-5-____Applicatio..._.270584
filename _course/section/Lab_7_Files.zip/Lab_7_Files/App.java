
// App Class
public class App {

    // Main application (to be completed by adding the view and the model subscribing to it)
    public static void main(String[] args) {
        // Assemble all the pieces of the MVC
        Model m = new Model(0);
        View v = new View("MVC Percentage View");
        m.subscribeToView(v);
        Controller c = new Controller("MVC Percentage Controller");
        c.initController();
        c.linkToModel(m);
    }
}