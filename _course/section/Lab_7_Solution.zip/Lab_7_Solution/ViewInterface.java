public interface ViewInterface {

void update(int valueToUpdate);

}
