public interface ControllerInterface {

    void updateModel();

}
