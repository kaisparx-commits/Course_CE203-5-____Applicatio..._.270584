import java.awt.FlowLayout;
import javax.swing.*;

// View Class
public class View implements ViewInterface {

    private final JTextField percentageTextfield;

    // View constructor (to be completed)
    public View(String title) {

        // Initialises View GUI
        // View uses Swing framework to display UI to user (to be completed by creating a new frame and text field)
        JFrame viewFrame = new JFrame(title);
        JLabel percentageLabel = new JLabel("Percentage of happy CE203 students :");
        percentageTextfield = new JTextField(20);
        percentageTextfield.setEditable(false);
        JPanel textPanel = new JPanel();
        textPanel.setLayout(new FlowLayout( FlowLayout.LEFT,20,10));
        textPanel.add(percentageLabel);
        textPanel.add(percentageTextfield);
        viewFrame.add(textPanel);
        viewFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        viewFrame.setSize(500, 200);
        viewFrame.setLocationRelativeTo(null);
        viewFrame.setVisible(true);
    }

    // Updates view component with parameter value (to be completed)
    public void update(int updatedValue)
    {
        percentageTextfield.setText(updatedValue+"%");
    }
}
