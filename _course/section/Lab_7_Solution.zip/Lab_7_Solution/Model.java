
// Model Class
public class Model implements ModelInterface{

    // Model attribute
    private int percentageValue;
    ViewInterface subscribedView1;

    // Model constructor
    public Model(int initialValue) {
        percentageValue = initialValue;
    }

    // Method that subscribes to a view
    public void subscribeToView(ViewInterface v)
    {
        subscribedView1 = v;
    }

    // Updates subscribed view(s) (to be completed by calling the update method in view)
    public void updateView() {

        subscribedView1.update(percentageValue);
        System.out.println("Text field updated to display new percentage value  --> Model updates View");
    }

    // get method for model attribute
    public int getModelValue()
    {
        return percentageValue;
    }

    // Set method for model attribute (to be completed, remember a change in value should update the view)
    public void setModelValue(int valueToSet) {

        percentageValue  = valueToSet;
        updateView();   // calls model's update method
    }
}

