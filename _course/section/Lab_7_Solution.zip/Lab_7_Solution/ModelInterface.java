public interface ModelInterface {

    void subscribeToView(ViewInterface v);

    void updateView();

    int getModelValue();

    void setModelValue(int setValue);

}
