/**
 * Created by id16214 on 10/5/2016.
 */
public class Rectangle extends Shape
{
    protected int cornerX;
    protected int cornerY;
    protected int width;
    protected int height;

    public Rectangle(int cornerX,int cornerY,int width, int height)
    {
        this.name="rectangle";
        this.cornerX=cornerX;
        this.cornerY=cornerX;
        this.width=width;
        this.height=height;
    }

    public void draw()
    {
        System.out.println("This is a rectangle with corner("+cornerX+","+cornerY+")and height "+height+" and width "+width);
    }
}
