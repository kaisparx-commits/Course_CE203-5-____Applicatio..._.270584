package Employees;

public class Development extends Employee
{
protected int NumberofprogramsD;

    public Development(int NumberofprogramsD, String name, int salary, String DoB, String EmployeeNumber){
        //super(name, salary, DOB, EmployeeNumber );


    this.name=name;
    this.salary=salary;
    this.DOB=DoB;
    this.EmployeeNumber=EmployeeNumber;
    this.NumberofprogramsD=NumberofprogramsD;
}


    @Override
    public void info() {

        System.out.println("The number  of programs developed by the employee are " + NumberofprogramsD );
    }

}
