package Employees;

public abstract class Employee
{
    protected String name;
    protected int salary;
    protected String DOB;
    protected String EmployeeNumber;




    public void printName()

    {

        System.out.println("Name= "+name +" ,the Salary of Employee, "+ salary + " ,the date of birth of the Employee" + DOB +" , the Employee number " + EmployeeNumber);
    }

    public void info () {

    }
}
