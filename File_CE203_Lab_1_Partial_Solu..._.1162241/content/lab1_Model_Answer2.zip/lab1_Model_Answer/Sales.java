package Employees;

public class Sales extends Employee
{
    protected int SalesRecorded;
    protected String  PointofSale;

    public Sales(int SalesRecorded, String PointofSale, String name, int salary, String DoB, String EmployeeNumber)
    {
        this.name=name;
        this.SalesRecorded=SalesRecorded;
        this.PointofSale=PointofSale;
        this.salary=salary;
        this.DOB=DoB;
        this.EmployeeNumber=EmployeeNumber;
    }

    @Override
    public void info()
    {
        System.out.println("The amount of products sold by the employee is " + SalesRecorded);
        System.out.println("The product was sold at point " + PointofSale);
    }
}
