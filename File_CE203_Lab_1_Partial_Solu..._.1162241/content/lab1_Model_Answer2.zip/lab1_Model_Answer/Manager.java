package Employees;

public class Manager extends Employee
{
    protected int NumberofStaff;


    public Manager(int Numberofstaff, String name, int salary, String DoB, String EmployeeNumber)
    {
        this.name=name;
        this.NumberofStaff=Numberofstaff;
        this.salary= salary;
        this.DOB=DoB;
        this.EmployeeNumber=EmployeeNumber;

    }

    @Override
    public void info()

            
    {
        System.out.println("The amount of employees managed is " + NumberofStaff);
    }
}
