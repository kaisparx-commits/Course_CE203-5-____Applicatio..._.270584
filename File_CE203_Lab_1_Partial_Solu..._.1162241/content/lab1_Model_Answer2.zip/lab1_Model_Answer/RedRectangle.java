/**
 * Created by id16214 on 10/5/2016.
 */
public class RedRectangle extends Rectangle
{
    public RedRectangle(int cornerX,int cornerY,int width, int height)
    {
        super(cornerX,cornerY,width,height);
        this.color="red";
    }
}

