/**
 * Created by id16214 on 10/5/2016.
 */
public abstract class Shape
{
    protected String name = "shape";
    protected String color = "black";

    public void printName()
    {
        System.out.println( "I am a " + color + " " + name );
    }
    public abstract void draw();
}
