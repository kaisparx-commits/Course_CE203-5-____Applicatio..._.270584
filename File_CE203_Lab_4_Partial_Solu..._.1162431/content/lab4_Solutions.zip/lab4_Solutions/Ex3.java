import java.util.ArrayList;
import java.util.List;

public class Ex3 {

    static void replaceNegList(List<Integer> l) {
        int current = 0;
        for(int i = 0; i < l.size(); i++) {
            // get current number
            current = l.get(i);
            // if number is negative
            if(current < 0) {
                // replace negative value with positive
                l.set(i, current * -1);
            }
        }
    }

    public static void main(String[] args) {

        // initialise list
        List<Integer> ls = new ArrayList<>();

        ls.add(1);
        ls.add(-3);
        ls.add(0);
        ls.add(-5);
        ls.add(2);

        System.out.println("ls: " + ls);

        // replace negatives
        replaceNegList(ls);

        // show changes
        System.out.println("ls: " + ls);
    }
}
