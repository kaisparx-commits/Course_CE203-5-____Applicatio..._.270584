import java.awt.*;

/**
 * Created by Faiyaz Doctor on 11/11/2021.
 */

public class Squares extends TopShape {

    public Squares(Integer posX, Integer posY, double sideLength) {
        super(posX, posY, sideLength);
    }

    // Overridden getArea method
    public Double getArea() {

        return this.shapeSize * this.shapeSize;
    }

    // Overridden draw method
    public void draw(Graphics g) {
        g.setColor(Color.YELLOW);

        // Need to convert shapeSize from a double to an int as g.fillRect only takes int arguments
        g.fillRect(this.posX, this.posY, (int)this.shapeSize, (int)this.shapeSize);
    }
}
