import java.awt.*;

/**
 * Created by Faiyaz Doctor on 11/11/2021.
 */

public class Circles extends TopShape {

    public Circles(Integer posX, Integer posY, Double radius) {

        // Calling constructor for TopShape
        super(posX, posY, radius);
    }

    // Overridden getArea method
    public Double getArea() {
        return Math.PI * this.shapeSize * this.shapeSize;
    }

    // Overridden getArea method
    public void draw(Graphics g) {
        g.setColor(Color.RED);

        // Need to convert shapeSize from a double to an int as g.fillRect only takes int arguments
        g.fillOval(this.posX, this.posY, (int)this.shapeSize, (int)this.shapeSize);
    }
}
