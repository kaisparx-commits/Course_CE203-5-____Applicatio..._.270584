import javax.swing.*;
import java.awt.*;

/**
 * Created by Faiyaz Doctor on 11/11/2021.
 */

public class ShapesPanel extends JPanel{

        DrawShapesCalc jframeRef;

        ShapesPanel(DrawShapesCalc jFRef) {
            jframeRef = jFRef;
        }

        public void paintComponent( Graphics g ) {
            super.paintComponent(g);
            jframeRef.shapes[0].draw(g);
            jframeRef.shapes[1].draw(g);
        }
}
