import java.awt.*;

/**
 * Created by Faiyaz Doctor on 11/11/2021.
 */

public abstract class TopShape {

    //Common data members inherited and used by subclasses
    Integer posX, posY;
    double shapeSize;

    public TopShape(Integer posX, Integer posY, double sSize) {
        this.posX = posX;
        this.posY = posY;
        shapeSize = sSize;
    }

    public void setShapeSize(double s)
    {
        shapeSize = s;
    }

    // abstract method getArea overridden and implemented in subclasses Circle and Square
    public abstract Double getArea();



    // abstract method draw overridden and implemented in subclasses Circle and Square
    public abstract void draw(Graphics g);

}
