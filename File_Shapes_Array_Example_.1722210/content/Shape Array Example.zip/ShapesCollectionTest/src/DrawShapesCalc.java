import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Faiyaz Doctor on 11/11/2021.
 */

public class DrawShapesCalc extends JFrame{

    TopShape[] shapes = new TopShape[2];
    JTextField txtField;

    public DrawShapesCalc() {

        // GUI panels
        JPanel panelOne;
        JPanel panelTwo;

        // window modification
        setTitle("Drawing shapes");
        setSize(800, 400);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        // instantiate shapes

        shapes[0] = new Squares(10, 10, 50);
        shapes[1] = new Circles((this.getWidth()/2) + 10, 10, 50d);


        // create paintable panelOne
        panelOne = new ShapesPanel(this);


        // create interactive UI panelTwo

        panelTwo = new JPanel();

        txtField = new JTextField(10);
        JButton btnSetSquare = new JButton("Set square size");
        JButton btnCalcSquareArea = new JButton("Calc square area");
        JButton btnSetCircle = new JButton("Set circle size");
        JButton btnCalcCircleArea = new JButton("Calc circle area");

        panelTwo.add(txtField);
        panelTwo.add(btnSetSquare);
        panelTwo.add(btnCalcSquareArea);
        panelTwo.add(btnSetCircle);
        panelTwo.add(btnCalcCircleArea);

        // add action listeners to buttons

        btnSetSquare.addActionListener(new ButtonHandler(this, 1));
        btnCalcSquareArea.addActionListener(new ButtonHandler(this, 2));
        btnSetCircle.addActionListener(new ButtonHandler(this, 3));
        btnCalcCircleArea.addActionListener(new ButtonHandler(this, 4));

        // add panels to frame

        add(panelOne, BorderLayout.CENTER);
        add(panelTwo, BorderLayout.SOUTH);

    }

    public static void main(String[] args) {
        new DrawShapesCalc().setVisible(true);
    }

}

class ButtonHandler implements ActionListener {

    private final DrawShapesCalc theApp;
    private final int action;

    public ButtonHandler(DrawShapesCalc theApp, int action) {
        this.theApp = theApp;
        this.action = action;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(this.action == 1) {
            // set square sideLength

           for (int i = 0; i < theApp.shapes.length; i++)
           {
               if(theApp.shapes[i] instanceof Squares)
               {
                   try {
                       this.theApp.shapes[i].setShapeSize(Double.parseDouble(theApp.txtField.getText()));
                       // repaint the JFrame
                       this.theApp.repaint();
                   } catch (NumberFormatException ex) {
                       System.out.println("Can't cast '" + theApp.txtField.getText() + "' to Double.");
                   }
                   break;
               }
           }
        }

        if(this.action == 2) {
            // calculate square area

            for (int i = 0; i < theApp.shapes.length; i++) {
                if (theApp.shapes[i] instanceof Squares) {
                    theApp.txtField.setText(Double.toString(theApp.shapes[i].getArea()));
                    break;
                }
            }

        }

        if(this.action == 3) {
            // set circle radius

            for (int i = 0; i < theApp.shapes.length; i++)
            {
                if(theApp.shapes[i] instanceof Circles)
                {
                    try {
                        this.theApp.shapes[i].setShapeSize(Double.parseDouble(theApp.txtField.getText()));
                        // repaint the JFrame
                        this.theApp.repaint();
                    } catch (NumberFormatException ex) {
                        System.out.println("Can't cast '" + theApp.txtField.getText() + "' to Double.");
                    }
                    break;
                }
            }

        }

        if(this.action == 4) {
            // calculate circle area

            for (int i = 0; i < theApp.shapes.length; i++) {
                if (theApp.shapes[i] instanceof Circles) {
                    theApp.txtField.setText(Double.toString(theApp.shapes[i].getArea()));
                    break;
                }
            }
        }
    }
}
