import java.util.ArrayList;
import java.util.Collections;

public class HeightWeightTest {

    public static void main(String[] args)
    {
        // new array list paramaterised to HumanHeightWeight objects
        ArrayList<HumanHeightWeight> heightArray = new ArrayList<HumanHeightWeight>();

        // add height weight objects to collection
        heightArray.add(new HumanHeightWeight("1.65", "66.5"));
        heightArray.add(new HumanHeightWeight("1.50", "70.1"));
        heightArray.add(new HumanHeightWeight("1.75", "60.5"));
        heightArray.add(new HumanHeightWeight("1.66", "67.9"));
        heightArray.add(new HumanHeightWeight("1.45", "83.1"));
        heightArray.add(new HumanHeightWeight("1.66", "54.3"));

        System.out.println("List of heights and weights (unsorted)");
        for (int i = 0; i < heightArray.size(); i++) {
            System.out.println(heightArray.get(i).toString());
        }

        // using collections.sort() to order heights based on meters
        Collections.sort(heightArray);

        System.out.println("");
        System.out.println("Sorted list of heights in meters ");
        for (int i = 0; i < heightArray.size(); i++) {
            System.out.println(heightArray.get(i).toString());
        }


        // using collections.sort() to order weights based on kgs using a Comparator object
        Collections.sort(heightArray, new CompareOnWeight());

        System.out.println("");
        System.out.println("Sorted list of weights in kgs");
        for (int i = 0; i < heightArray.size(); i++) {
            System.out.println(heightArray.get(i).toString());
        }

    }

}
