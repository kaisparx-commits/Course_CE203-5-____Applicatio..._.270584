import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RedBlue extends JFrame
{
    boolean blue;
    JPanel panel;

    public RedBlue()
    {
        blue = false;
        JButton button = new JButton("Press here");
        button.addActionListener(new ButtonHandler(this));
        panel = new MyPanel(this);
        Container c = getContentPane();
        c.add(button, BorderLayout.SOUTH);
        c.add(panel, BorderLayout.CENTER);
    }

    public static void main( String[] args )
    {
        RedBlue rbF = new RedBlue();
        rbF.setSize( 300, 300 );
        rbF.setVisible( true );
    }
}

class MyPanel extends JPanel
{ private RedBlue myApp;

    public MyPanel(RedBlue applet)
    { myApp = applet;
    }

    public void paintComponent(Graphics g)
    { super.paintComponent(g);
        if (myApp.blue)
        { g.setColor(Color.blue);
            g.fillRect(50,100,50,50);
        }
        else
        { g.setColor(Color.red);
            g.drawRect(50,100,50,50);
        }
    }
}

class ButtonHandler implements ActionListener
{ private RedBlue myApp;

    public ButtonHandler(RedBlue applet)
    { myApp = applet;
    }

    public void actionPerformed(ActionEvent e)
    { myApp.blue = !myApp.blue;
        myApp.panel.repaint();
    }
}

